import java.awt.BorderLayout;

import java.util.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;

public class course extends JFrame {
 
	private JPanel contentPane;
	private JTextField textFieldname;
	private JTextField textFieldfee;
	private JTextField textFielddoc;
	private JTextField textFielded;
	private boolean bool=false;

 private static int p=0;
     
     public void setbool(boolean b){
    	 
    	 bool=b;
     }
     
     public int getcourses(){
    	 return p;
     }
     
     public void setcourses(int q){
    	 p=q;
    	 
     }
    
     
    SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy");
    private int k=0,f=0,n=0;//k=participants;m=faculty;n=headfac;
    private String name;
    private String fee;
    private String date;
    private String duration;
    private Date date1;
    private Date dur;
    faculty headfac;
  
    static LinkedList<faculty> fac=new LinkedList<faculty>();

    static LinkedList<Participant> part=new LinkedList<Participant>();
  
    
    public void setparticipants(int a){
        
        k=a;
 
    }    
    public int getparticipants(){
    
    return k;
    }
    
    
    
   public void setfaculty(int a){
        
        f=a;
    }
    
    public int getfaculty(){
    
    return f;
    }
    
    
     public void setheadfaculty(int a){
        
        n=a;
    }
    
    public int getheadfaculty(){
    
    return n;
    }
    
    

    
    public void name(String s){
    
    name=s;
    }
    public String getname(){
    
    return name;
    }
     public void fee(String s){
    
    fee=s;
    }
    public String getfee(){
    
    return fee;
    
}






     public void date(String s){
    
    date=s;
    }
  
    
    
    
    
    
    
    public String getdate(){
    
    return date;
    }
    

    
    public String getduration(){
    
        return duration;
    }
    
    public void setduration(String s)throws Exception{

        dur=df.parse(s);
        
        duration=df.format(dur);
    }
    
    
    
    
    
    
    
    
    public void headfac(String s){
    
    headfac.name(s);
    }
    public String getheadfacname(){
    
       return headfac.getname();
    }
    
    public void datify(String s)throws Exception{
    
    date1=df.parse(s);
    date=df.format(date1);
        
    }
    
    
    
   
    
    
    
    
    
    //participants registered for course number num;
    
    public void displayallparticipants(){
    Display dp=new Display();
    int q=0;
    while(q<k){    	
    dp.getdisplaypane().append("participant"+q+":\n");
   	dp.getdisplaypane().append(part.get(q).getname()+"\n");
   	dp.getdisplaypane().append(part.get(q).getaddress()+"\n");
   	dp.getdisplaypane().append(part.get(q).getmobileno()+"\n");
   	dp.getdisplaypane().append(part.get(q).getorganisationname()+"\n");
    dp.getdisplaypane().append(part.get(q).getmail()+"\n");
    q++;
    dp.getdisplaypane().append("\n");
    }
    dp.setVisible(true);
     
    }
    
   
     public void displayallfaculty(){
    Display dp=new Display();	 
    int q=0;
    while(q<f){
    dp.getdisplaypane().append("faculty"+q+":\n");
    dp.getdisplaypane().append(fac.get(q).getname()+"\n");
    dp.getdisplaypane().append(fac.get(q).getaddress()+"\n");
    dp.getdisplaypane().append(fac.get(q).getmobileno()+"\n");
    dp.getdisplaypane().append(fac.get(q).getdept()+"\n");
    dp.getdisplaypane().append(fac.get(q).getmail()+"\n");
    q++;
    dp.getdisplaypane().append("\n");
    }
    dp.setVisible(true); 
    
    }
    
      public void displayheadfaculty(){
          Display dp=new Display();
       if(n==1){   
    System.out.println();
    dp.getdisplaypane().append("headfaculty:\n");
    dp.getdisplaypane().append(headfac.getname()+"\n");
    dp.getdisplaypane().append(headfac.getaddress()+"\n");
    dp.getdisplaypane().append(headfac.getmobileno()+"\n");
    dp.getdisplaypane().append(headfac.getdept()+"\n");
    dp.getdisplaypane().append(headfac.getmail()+"\n");
    dp.getdisplaypane().append("\n");
       
     }
     
       dp.setVisible(true);
       
    }
    
    
    
    
   
    
   
    
    public long getdiff()throws Exception{
    
    long a,b;
    Date d=new Date();
    date1=df.parse(date);
    a=date1.getTime();
    b=d.getTime();
    
    if(a>b){
    //return  (a-b)/(86400*1000);}
    
    return 0;}
    
    else{
        
    return  (b-a)/(86400*1000);
    
    }
    
    
    
    
    
    }
    
    
    
    public long chckdur()throws Exception{
    
        long  a,b;
        Date d=df.parse(date);
        dur=df.parse(duration);
        a=dur.getTime();
        b=d.getTime();
        
       return (a-b)/(86400*1000);
    }
    
    
    
    
    
    public int getyear()throws Exception{
    
    date1=df.parse(date);
   
    Calendar c=Calendar.getInstance();
    
    c.setTime(date1);
    
    int k=c.get(Calendar.YEAR);
   
    return k;
    
    }
    
    
    
    
    
    
    
    
    
    
    
    

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					course frame = new course();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public course() {
		setTitle("COURSE");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 656, 491);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("NAME");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblName.setBounds(10, 11, 60, 22);
		contentPane.add(lblName);
		
		JLabel lblFee = new JLabel("FEE");
		lblFee.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblFee.setBounds(10, 68, 46, 22);
		contentPane.add(lblFee);
		
		JLabel lblDateOfCreation = new JLabel("DATE OF CREATION");
		lblDateOfCreation.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDateOfCreation.setBounds(10, 115, 164, 29);
		contentPane.add(lblDateOfCreation);
		
		JLabel lblEndDate = new JLabel("END DATE");
		lblEndDate.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEndDate.setBounds(10, 175, 94, 22);
		contentPane.add(lblEndDate);
		
		JLabel lblHeadFaculty = new JLabel("HEAD FACULTY");
		lblHeadFaculty.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblHeadFaculty.setBounds(10, 303, 129, 22);
		contentPane.add(lblHeadFaculty);
		
		JButton btnOpen = new JButton("Display");
		btnOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				displayheadfaculty();
			}
		});
		btnOpen.setBounds(337, 306, 89, 23);
		contentPane.add(btnOpen);
		
		JLabel lblFaculty = new JLabel("FACULTY");
		lblFaculty.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblFaculty.setBounds(10, 240, 82, 22);
		contentPane.add(lblFaculty);
		
		textFieldname = new JTextField();
		textFieldname.setBounds(237, 15, 354, 20);
		contentPane.add(textFieldname);
		textFieldname.setColumns(10);
		
		textFieldfee = new JTextField();
		textFieldfee.setBounds(237, 72, 354, 20);
		contentPane.add(textFieldfee);
		textFieldfee.setColumns(10);
		
		textFielddoc = new JTextField();
		textFielddoc.setBounds(237, 122, 354, 20);
		contentPane.add(textFielddoc);
		textFielddoc.setColumns(10);
		
		textFielded = new JTextField();
		textFielded.setBounds(237, 179, 354, 20);
		contentPane.add(textFielded);
		textFielded.setColumns(10);
		
		JButton btnNewButton = new JButton("Display");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				displayallfaculty();
				
			}
		});
		btnNewButton.setBounds(337, 243, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblParticipants = new JLabel("PARTICIPANTS");
		lblParticipants.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblParticipants.setBounds(10, 362, 129, 22);
		contentPane.add(lblParticipants);
		
		JButton btnOpen_1 = new JButton("Display");
		btnOpen_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				displayallparticipants();
			}
		});
		btnOpen_1.setBounds(337, 365, 89, 23);
		contentPane.add(btnOpen_1);
		
		JButton btnCreate = new JButton("create new");
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				fac.add(new faculty());
				if(f<5){
				fac.get(f).setVisible(true);
				fac.get(f).sendname(name);
				 }
				else{JOptionPane.showMessageDialog(null, "faculty exceeding 5");}
				
			}
		});
		btnCreate.setBounds(483, 243, 89, 23);
		contentPane.add(btnCreate);
		
		JButton btnCreateNew = new JButton("create new");
		btnCreateNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				
				if(n==0){
				headfac.sethead(true);	
				headfac.setVisible(true);}
				else{
					
					JOptionPane.showMessageDialog(null, "Headfaculty already assigned");
				}
				
				
				//HEAD FACULTY CREATE
				
				
				
				
				
				
			}
		});
		btnCreateNew.setBounds(483, 306, 89, 23);
		contentPane.add(btnCreateNew);
		
		JButton btnCreateNew_1 = new JButton("create new");
		btnCreateNew_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				
				
				part.add(new Participant());
				if(k<5){
				part.get(k).setVisible(true);
				part.get(k).sendname(name);
				 }
				else{JOptionPane.showMessageDialog(null, "participants exceeding 5");}
				
				
				
			}
		});
		btnCreateNew_1.setBounds(483, 365, 89, 23);
		contentPane.add(btnCreateNew_1);
		
		JButton btnSaveCourse = new JButton("Save Course");
		btnSaveCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
		
				boolean flag=true;
				
				
				  if(p==50){System.out.println("50 courses already created for the current year");}
			       
		
			         name=textFieldname.getText();
			      
			         fee=textFieldfee.getText();
			       
			          try {
						datify(textFielddoc.getText());
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "enter valid date of creation format");
					
					  flag=false;
					}
			          
			          
			  
			          try {
						setduration(textFielded.getText());
					    
			          
			          } catch (Exception e) {
						JOptionPane.showMessageDialog(null, "enter valid end date format");
				       flag=false;
					}
			          
			          if(flag){
			          
			          try {
						if(chckdur()>14){
						      
							  JOptionPane.showMessageDialog(null,"duration cannot be more than 2 weeks!!...re-enter last date");
							  flag=false;

						  }
					} catch (HeadlessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			   
			          }
			          
			          
			   if(flag){
				   
				   
				   
				   try {
					if(getdiff()>1825){
						String s=name;
						mcourse m=new mcourse();
						        m.c.remove(p);
						        dispose();
						        JOptionPane.showMessageDialog(null, "course"+s+"has been deleted due to expiry");
						        flag=false;
						
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				   
				
				 if(flag){ 
					 
				if(bool==false){	 
			     p++;bool=true;}
			     
			     
			     dispose();}}
				
				
			}
		});
		btnSaveCourse.setBounds(160, 419, 142, 23);
		contentPane.add(btnSaveCourse);
		
		JButton btnDeleteCourse = new JButton("Delete Course");
		btnDeleteCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				
			if(bool){	
				String s=name;
				mcourse m=new mcourse();
				int y=0;
				 for(y=0;y<p;++y){
				        if(s.compareToIgnoreCase(m.c.get(y).getname())==0)break;
				        }
				
				        m.c.remove(y);
				        p--;
				        dispose();
				        JOptionPane.showMessageDialog(null, "course "+s+" has been deleted");
				 
				   
			}
			
			else{JOptionPane.showMessageDialog(null, "Course doesn't exist");}
			
			}
		});
		btnDeleteCourse.setBounds(371, 419, 142, 23);
		contentPane.add(btnDeleteCourse);
		
		
		 headfac=new faculty();
	       for(int i=0;i<20;++i){//althogh at every instance of creating a fac or participant in asg1 class ,it is instantiated..but to be on safer side for loop is used
	    
	    fac.add(new faculty());
	    part.add(new Participant());
	    
	}
		
		
		
		
		
	}
}

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Participant extends JFrame {

	private JPanel contentPane; 
	private JTextField textFieldna;
	private JTextField textFieldad;
	private JTextField textFieldmo;
	private JTextField textFieldor;
    private boolean bool=false;
	
	    private String name;
	    private String address;
	    private String mobileno;
	    private String organisationname;
	    private String e_mail;
	    private JTextField textFieldem;
	    private String cname;
	    
	    
	    
	    
	    public void setbool(boolean b){
	    	
	    	bool=b;
	    }
	    
	    public void sendname(String q){
	    	
	    	cname=q;
	    }
	    
	    
	    
	    public void name(String n){
	    
	    name=n;
	    
	    }
	   
	    
	    public void address(String n){
	    
	    address=n;
	    
	    }
	    
	    public void mobileno(String n){
	    
	    mobileno=n;
	    
	    }
	    
	    
	    public void organisationname(String n){
	    
	    organisationname=n;
	    
	    }
	    
	    
	    public void mail(String n){
	    
	    e_mail=n;
	    
	    }
	    
	     public String getname(){
	    
	    return name;
	    
	    }
	    
	     public String getaddress(){
	    
	    return address;
	    
	    }
	    
	     public String getmobileno(){
	    
	    return mobileno;
	    
	    }
	    
	     public String getorganisationname(){
	    
	    return organisationname;
	    
	    }
	    
	     public String getmail(){
	    
	    return e_mail;
	    
	    }
	    
	    
	
	
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Participant frame = new Participant();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Participant() {
		setTitle("PARTICIPANT");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 571, 396);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("NAME");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblName.setBounds(20, 42, 65, 22);
		contentPane.add(lblName);
		
		JLabel lblAddress = new JLabel("ADDRESS");
		lblAddress.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblAddress.setBounds(20, 97, 85, 22);
		contentPane.add(lblAddress);
		
		JLabel lblMobileno = new JLabel("MOBILE.NO");
		lblMobileno.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblMobileno.setBounds(20, 153, 94, 22);
		contentPane.add(lblMobileno);
		
		JLabel lblOrganisationname = new JLabel("ORGANISATION-NAME");
		lblOrganisationname.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblOrganisationname.setBounds(20, 209, 200, 22);
		contentPane.add(lblOrganisationname);
		
		JLabel lblEmail = new JLabel("E_MAIL");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEmail.setBounds(20, 267, 144, 22);
		contentPane.add(lblEmail);
		
		textFieldna = new JTextField();
		textFieldna.setBounds(227, 46, 294, 20);
		contentPane.add(textFieldna);
		textFieldna.setColumns(10);
		
		textFieldad = new JTextField();
		textFieldad.setBounds(227, 101, 294, 20);
		contentPane.add(textFieldad);
		textFieldad.setColumns(10);
		
		textFieldmo = new JTextField();
		textFieldmo.setBounds(227, 157, 294, 20);
		contentPane.add(textFieldmo);
		textFieldmo.setColumns(10);
		
		textFieldor = new JTextField();
		textFieldor.setBounds(227, 213, 294, 20);
		contentPane.add(textFieldor);
		textFieldor.setColumns(10);
		
		textFieldem = new JTextField();
		textFieldem.setBounds(227, 271, 294, 20);
		contentPane.add(textFieldem);
		textFieldem.setColumns(10);
		
		JButton btnSave = new JButton("save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				name=textFieldna.getText();
				address=textFieldad.getText();
				mobileno=textFieldmo.getText();
				organisationname=textFieldor.getText();
				e_mail=textFieldem.getText();
				
				if(bool==false){
					
					mcourse mc=new mcourse();
					int y=0;
					for(y=0;y<mc.c.get(0).getcourses();y++){
						
						if(cname.compareToIgnoreCase(mc.c.get(y).getname())==0){ break;}
						
					}
					
					
				int f=mc.c.get(y).getparticipants();
				mc.c.get(y).setparticipants(f+1);
					bool=true;
				}
				
				dispose();
				
				
			}
		});
		btnSave.setBounds(168, 324, 89, 23);
		contentPane.add(btnSave);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
               if(bool==true){
					
					mcourse mc=new mcourse();
					int y=0;
					for(y=0;y<mc.c.get(0).getcourses();y++){
						
						if(cname.compareToIgnoreCase(mc.c.get(y).getname())==0){ break;}
						
					}
					
					
				int f=mc.c.get(y).getparticipants();
				mc.c.get(y).setparticipants(f-1);
			    int a=y;
					
					
					for(y=0;y<f;++y){
						
						if(name.compareToIgnoreCase(mc.c.get(a).part.get(y).getname())==0){break;}
						
						
					}	
						
					mc.c.get(a).part.remove(y);
					
				}
               
               
               else{
            	   
            	   
            	   JOptionPane.showMessageDialog(null, "Participant doesn't exist");
            	   
               }
				
				
				
				
				
			}
		});
		btnDelete.setBounds(292, 324, 89, 23);
		contentPane.add(btnDelete);
	}

}

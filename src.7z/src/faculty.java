import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class faculty extends JFrame {

	private JPanel contentPane; 
	private JTextField textFieldn;
	private JTextField textFielda;
	private JTextField textFieldm;
	private JTextField textFieldd;
	private JTextField textFielde;
    private boolean bool=false; 
	private boolean head=false;
	
	
	private String cname;
	
	
	 public void setbool(boolean b){
		 
		 bool=b;
	 }
	
	
	public void sethead(boolean b){
		
		head=b;
	}
	
	
	
	
	public void sendname(String a){
		cname=a;
		
	}

    private String dept;
    private String name;
    private String address;
    private String mobileno;
    private String e_mail;
  
   public void dept(String s){
   
   dept=s;
   }
    public void name(String s){
   
   name=s;
   }
   public String getname(){
   
       return name;
   
   }
   
    public void address(String s){
   
   address=s;
   }
    public void mobileno(String s){
   
   mobileno=s;
   }
    public void mail(String s){
   
   e_mail=s;
   }
  public String getdept(){
   
       return dept;
   
   }
   public String getaddress(){
   
       return address;
   
   }
   public String getmobileno(){
   
       return mobileno;
   
   }
   public String getmail(){
   
       return e_mail;
   
   }
 
   
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					faculty frame = new faculty();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public faculty() {
		setFont(new Font("Dialog", Font.PLAIN, 11));
		setTitle("FACULTY");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 510, 434);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("NAME");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(28, 35, 58, 27);
		contentPane.add(lblNewLabel);
		
		JLabel lblAddress = new JLabel("ADDRESS");
		lblAddress.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblAddress.setBounds(28, 95, 82, 27);
		contentPane.add(lblAddress);
		
		JLabel lblMobileno = new JLabel("MOBILE.NO");
		lblMobileno.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblMobileno.setBounds(28, 162, 100, 27);
		contentPane.add(lblMobileno);
		
		JLabel lblDepartment = new JLabel("DEPARTMENT");
		lblDepartment.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDepartment.setBounds(28, 226, 112, 27);
		contentPane.add(lblDepartment);
		
		JLabel lblEmail = new JLabel("E_MAIL");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEmail.setBounds(28, 285, 85, 36);
		contentPane.add(lblEmail);
		
		textFieldn = new JTextField();
		textFieldn.setBounds(185, 41, 299, 20);
		contentPane.add(textFieldn);
		textFieldn.setColumns(10);
		
		textFielda = new JTextField();
		textFielda.setBounds(185, 101, 299, 20);
		contentPane.add(textFielda);
		textFielda.setColumns(10);
		
		textFieldm = new JTextField();
		textFieldm.setBounds(185, 168, 299, 20);
		contentPane.add(textFieldm);
		textFieldm.setColumns(10);
		
		textFieldd = new JTextField();
		textFieldd.setBounds(185, 232, 299, 20);
		contentPane.add(textFieldd);
		textFieldd.setColumns(10);
		
		textFielde = new JTextField();
		textFielde.setBounds(185, 296, 299, 20);
		contentPane.add(textFielde);
		textFielde.setColumns(10);
		
		JButton btnSave = new JButton("save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			if(!head){	
				mcourse cr=new mcourse();
				name=textFieldn.getText();
				address=textFielda.getText();
				mobileno=textFieldm.getText();
				dept=textFieldd.getText();
				e_mail=textFielde.getText();
				if(bool==false){
					mcourse mc=new mcourse();
					int y=0;
					for(y=0;y<mc.c.get(0).getcourses();y++){
						
						if(cname.compareToIgnoreCase(mc.c.get(y).getname())==0){ break;}
						
					}
					
					
				int f=mc.c.get(y).getfaculty();
				mc.c.get(y).setfaculty(f+1);
					bool=true;}
				dispose();}
			
			else{
				
				mcourse cr=new mcourse();
				name=textFieldn.getText();
				address=textFielda.getText();
				mobileno=textFieldm.getText();
				dept=textFieldd.getText();
				e_mail=textFielde.getText();
				mcourse mc=new mcourse();
				int y=0;
				for(y=0;y<mc.c.get(0).getcourses();y++){
					
					if(cname.compareToIgnoreCase(mc.c.get(y).getname())==0){ break;}
					
				}
				mc.c.get(y).setheadfaculty(1);
				
			}
			
			}
		});
		btnSave.setBounds(158, 362, 89, 23);
		contentPane.add(btnSave);
		
		JButton btnNewButton = new JButton("Delete");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				if(bool==false){  
					
					if(head==false){
					JOptionPane.showMessageDialog(null, "Faculty doesn't exist");}
					
					else{
						mcourse mc=new mcourse();
						int y=0;
						for(y=0;y<mc.c.get(0).getcourses();y++){
							
							if(cname.compareToIgnoreCase(mc.c.get(y).getname())==0){ break;}
							
						}
					mc.c.get(y).headfac=new faculty();
					head=bool=false;
					mc.c.get(y).setheadfaculty(0);						
					}
				
				
				}
				
				else{
					mcourse mc=new mcourse();
					int y=0;
					for(y=0;y<mc.c.get(0).getcourses();y++){
						
						if(cname.compareToIgnoreCase(mc.c.get(y).getname())==0){ break;}
						
					}
					
					
				int f=mc.c.get(y).getfaculty();
				mc.c.get(y).setfaculty(f-1);
				int a=y;
					
				for(y=0;y<f;++y){
					
					if(name.compareToIgnoreCase(mc.c.get(a).fac.get(y).getname())==0){break;}
					
					
				}	
					
				mc.c.get(a).fac.remove(y);
				}
				
				
			}
		});
		btnNewButton.setBounds(271, 362, 89, 23);
		contentPane.add(btnNewButton);
	}
}

import java.awt.EventQueue;
import java.util.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.*;

public class mcourse { 

	private JFrame frame;
	private JTextField textFieldoc;
	    
     static LinkedList<course> c=new LinkedList<course>();
   
     
     int num=0,y=0,a=0,r=0,u=0,g=0,h=0;
     String str;
        Scanner myvar=new Scanner(System.in);
        private JTextField textFieldof;
        private JTextField textFieldop;
        
        

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mcourse window = new mcourse();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public mcourse() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 716, 493);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblCreateCourse = new JLabel("Create Course");
		lblCreateCourse.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblCreateCourse.setBounds(26, 41, 115, 22);
		frame.getContentPane().add(lblCreateCourse);
		
		JLabel lblDisplayCourses = new JLabel("Display courses");
		lblDisplayCourses.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDisplayCourses.setBounds(26, 99, 128, 22);
		frame.getContentPane().add(lblDisplayCourses);
		
		JLabel lblOpenACourse = new JLabel("Open Course");
		lblOpenACourse.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblOpenACourse.setBounds(26, 162, 115, 22);
		frame.getContentPane().add(lblOpenACourse);
		
		JLabel lblNewLabel = new JLabel("Save to file");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(26, 365, 103, 22);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewCourse = new JButton("New course");
		btnNewCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				c.add(new course());
				int p=c.get(0).getcourses();
				c.get(p).setVisible(true);

			}		});
		btnNewCourse.setBounds(238, 40, 89, 23);
		frame.getContentPane().add(btnNewCourse);
		
		JButton btnDisplay = new JButton("Display ");
		btnDisplay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				Display dp=new Display();
				
				
				 for(y=0;y<c.get(0).getcourses();++y){
			         
			         dp.getdisplaypane().append("course"+y+"\n");  
			           
			         dp.getdisplaypane().append(c.get(y).getname()+"\n");
			       
			        
			         dp.getdisplaypane().append(c.get(y).getfee()+"\n");
			     
			        
			         dp.getdisplaypane().append(c.get(y).getdate()+"\n");
			       
			        
			         dp.getdisplaypane().append(c.get(y).getduration()+"\n");
			      
			        }
				
				
				dp.setVisible(true);
			}
		});
		btnDisplay.setBounds(238, 98, 89, 23);
		frame.getContentPane().add(btnDisplay);
		
		textFieldoc = new JTextField();
		textFieldoc.setBounds(238, 166, 230, 20);
		frame.getContentPane().add(textFieldoc);
		textFieldoc.setColumns(10);
		
		JButton btnOpen = new JButton("Open");
		btnOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				c.add(new course());
				int y=0,a=c.get(0).getcourses();
				String s=textFieldoc.getText();
				
				for(y=0;y<a;++y){
					
					if(s.compareToIgnoreCase(c.get(y).getname())==0){break; }
					
					
				}
				
				if(y==a){JOptionPane.showMessageDialog(null, "No such course exists");}
				
				else{   c.get(y).setVisible(true);      }
				
				
				
			}
		});
		btnOpen.setBounds(522, 161, 89, 23);
		frame.getContentPane().add(btnOpen);
		
		JLabel lblReadFromFile = new JLabel("Read from file");
		lblReadFromFile.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblReadFromFile.setBounds(26, 422, 128, 22);
		frame.getContentPane().add(lblReadFromFile);
		
		JLabel lblOpenFaculty = new JLabel("Open Faculty");
		lblOpenFaculty.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblOpenFaculty.setBounds(26, 235, 115, 22);
		frame.getContentPane().add(lblOpenFaculty);
		
		textFieldof = new JTextField();
		textFieldof.setBounds(238, 239, 230, 20);
		frame.getContentPane().add(textFieldof);
		textFieldof.setColumns(10);
		
		JButton btnNewButton = new JButton("Open");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String s=textFieldof.getText();
				c.add(new course());
				  u=0;
				  int p=c.get(0).getcourses();
			    
			        for(y=0;y<p;++y){
			            
			            for(a=0;a<c.get(y).getfaculty();a++){
			        if(s.compareToIgnoreCase(c.get(y).fac.get(a).getname())==0){u=1;break;}
			        }
			    if(u==1)break;
			    }
			        
			         if(u!=1){
			        	 
			        	 
			        	 for(y=0;y<p;y++){
			        	        if(s.compareToIgnoreCase(c.get(y).headfac.getname())==0){u=2;break;}
			        	        }
			        	             
			        	          if(u==2){ c.get(y).headfac=new faculty();c.get(y).setheadfaculty(0);}   
			        	             
			        	        
			        	            else{ 
			        	         
			                   

			        	 JOptionPane.showMessageDialog(null, "NO such faculty exists");
			        	            }
			        	 
			         }
			         
			         else{
			         c.get(y).fac.get(a).setVisible(true);
			         }
				        		
			}
		});
		btnNewButton.setBounds(522, 238, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblOpenParticipant = new JLabel("Open Participant");
		lblOpenParticipant.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblOpenParticipant.setBounds(26, 306, 161, 22);
		frame.getContentPane().add(lblOpenParticipant);
		
		textFieldop = new JTextField();
		textFieldop.setBounds(238, 310, 230, 20);
		frame.getContentPane().add(textFieldop);
		textFieldop.setColumns(10);
		
		JButton btnOpen_1 = new JButton("Open");
		btnOpen_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			
				String s=textFieldop.getText();
				c.add(new course());
				  u=0;
				  int p=c.get(0).getcourses();
			    
			        for(y=0;y<p;++y){
			            
			            for(a=0;a<c.get(y).getparticipants();a++){
			        if(s.compareToIgnoreCase(c.get(y).part.get(a).getname())==0){u=1;break;}
			        }
			    if(u==1)break;
			    }
			        
			         if(u!=1){
			                   

			        	 JOptionPane.showMessageDialog(null, "No such participant exists");
			         
			        	 
			         }
			         
			         else{
			         c.get(y).part.get(a).setVisible(true);
			         }
			
			}
		});
		btnOpen_1.setBounds(522, 309, 89, 23);
		frame.getContentPane().add(btnOpen_1);
		
		JButton btnRead = new JButton("Read");
		btnRead.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				  c.add(new course());
		      		
				   JFileChooser fc=new JFileChooser();
				   fc.setVisible(true);
				   if(fc.showOpenDialog(null)==JFileChooser.APPROVE_OPTION){
					   
				   String s=fc.getSelectedFile().getAbsolutePath();   
			       File f=new File(s);
			       try {
					myvar=new Scanner(f);
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			        
			        s=myvar.nextLine();//courses
			        c.get(0).setcourses(Integer.parseInt(s));
			        int p=c.get(0).getcourses();
			        y=0;
			        while(y<p){
			        s=myvar.nextLine();
			        c.add(new course());
			        c.get(y).name(myvar.nextLine());
			        c.get(y).fee(myvar.nextLine());
			        c.get(y).date(myvar.nextLine());
			        try {
						c.get(y).setduration(myvar.nextLine());
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			        c.get(y).setbool(true);
			        s=myvar.nextLine();
			        s=myvar.nextLine();
			        int A=Integer.parseInt(s);
			        if(A==1){//head faculty
			          c.get(y).setheadfaculty(1);  
			          s=myvar.nextLine();
			        
			        c.get(y).headfac.name(myvar.nextLine());
			     
			        c.get(y).headfac.address(myvar.nextLine());
			             
			        c.get(y).headfac.mobileno(myvar.nextLine());
			            
			        c.get(y).headfac.dept(myvar.nextLine());
			           
			        c.get(y).headfac.mail(myvar.nextLine());
			        
			        c.get(y).headfac.sethead(true);
			        
			        }
			        else {c.get(y).setheadfaculty(0);}
			        
			        s=myvar.nextLine();//faculty
			        A=Integer.parseInt(s);
			        c.get(y).setfaculty(A);
			        
			        for(r=0;r<A;++r){
			         s=myvar.nextLine();
			         s=myvar.nextLine();
			       c.get(y).fac.add(new faculty());
			            c.get(y).fac.get(r).name(myvar.nextLine());
			     
			            c.get(y).fac.get(r).address(myvar.nextLine());
			             
			            c.get(y).fac.get(r).mobileno(myvar.nextLine());
			            
			            c.get(y).fac.get(r).dept(myvar.nextLine());
			           
			            c.get(y).fac.get(r).mail(myvar.nextLine());
			        
			            c.get(y).fac.get(r).setbool(true);
			        }    
			        
			        
			         s=myvar.nextLine();//participants
			         A=Integer.parseInt(s);
			         c.get(y).setparticipants(A);
			         for(r=0;r<A;++r){ 
			         s=myvar.nextLine();
			         s=myvar.nextLine();
			         c.get(y).part.add(new Participant());
			         c.get(y).part.get(r).name(myvar.nextLine());
			     
			         c.get(y).part.get(r).address(myvar.nextLine());
			          
			         c.get(y).part.get(r).mobileno(myvar.nextLine());
			           
			         c.get(y).part.get(r).organisationname(myvar.nextLine());
			     
			         c.get(y).part.get(r).mail(myvar.nextLine());   
			           
			         c.get(y).part.get(r).setbool(true);
			             }
			        
			        
			        y++;
			        
			        s=myvar.nextLine();
			        
			        }
			        
			       myvar.close();
			       
			       for(y=0;y<p;++y){
			        
			        try {
						if(c.get(y).getdiff()>1825)
						{
						
						JOptionPane.showMessageDialog(null,"course :"+c.get(y).getname()+" has expired");
      c.remove(y);
      y--;p--;
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			  
			        }
				
				
				   }
				
				
				
				
				
				
			}
		});
		btnRead.setBounds(238, 421, 89, 23);
		frame.getContentPane().add(btnRead);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				JFileChooser fc=new JFileChooser();
				
				fc.setVisible(true);
				
				int q=fc.showOpenDialog(null);
				
				if(q==JFileChooser.APPROVE_OPTION){
					
					
					String s=fc.getSelectedFile().getAbsolutePath();
					
					  PrintWriter pw=null;
					try {
						pw = new PrintWriter(s);
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				       int p=c.get(0).getcourses();
				       y=0;
				       pw.println(p);
				       while(y<p){  
				       
				       pw.println("course"+y+":");
				       //pw.println();
				       pw.println(c.get(y).getname());
				       // pw.println();
				       pw.println(c.get(y).getfee());
				       // pw.println();
				       pw.println(c.get(y).getdate());
				       
				       pw.println(c.get(y).getduration());
				        
				       pw.println();
				       pw.println(c.get(y).getheadfaculty());
				        if(c.get(y).getheadfaculty()==1){
				        	
				                pw.println("headfaculty");
				                
				            pw.println(c.get(y).headfac.getname());
				     
				            pw.println(c.get(y).headfac.getaddress());
				             
				            pw.println(c.get(y).headfac.getmobileno());
				            
				            pw.println (c.get(y).headfac.getdept());
				           
				            pw.println (c.get(y).headfac.getmail());
				 
				        }
				       
				       pw.println(c.get(y).getfaculty());
				       
				       for(a=0;a<c.get(y).getfaculty();++a){
				    	   
				       pw.println();
				       
				       pw.println("faculty"+a+":");
				       
				      
				   
				            pw.println(c.get(y).fac.get(a).getname());
				     
				            pw.println(c.get(y).fac.get(a).getaddress());
				             
				            pw.println(c.get(y).fac.get(a).getmobileno());
				            
				            pw.println (c.get(y).fac.get(a).getdept());
				           
				            pw.println (c.get(y).fac.get(a).getmail());
				        
				           
				        }    
				            pw.println(c.get(y).getparticipants());
				            
				            for(a=0;a<c.get(y).getparticipants();++a){
				            	
				            pw.println();
				            
				            pw.println("participant"+a+":");
				        
				            pw.println(c.get(y).part.get(a).getname());
				     
				            pw.println(c.get(y).part.get(a).getaddress());
				          
				            pw.println(c.get(y).part.get(a).getmobileno());
				           
				            pw.println(c.get(y).part.get(a).getorganisationname());
				     
				            pw.println(c.get(y).part.get(a).getmail());   
				           
				             }
				           
				           
				          y++;
				          
				          pw.println();
				           
				        }
				        
				        pw.close();
						
				}
				
	
			}
		});
		btnSave.setBounds(238, 368, 89, 23);
		
		frame.getContentPane().add(btnSave);
	}
}
